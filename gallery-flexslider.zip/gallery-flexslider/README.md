# gallery-flexslider
Wordpress plugin to insert a responsive slider and carousels from galleries in custom posts. 

It is an extention of a simple plugin that integrates FlexSlider (http://flex.madebymufffin.com/) with WordPress using custom post types! 

You can find the base version on the following post, 

http://code.tutsplus.com/articles/create-a-responsive-slider-plugin-with-flexslider-for-wordpress--wp-21839
